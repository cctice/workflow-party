# Project Context

KFC 支持为项目登记稳定上下文入口。上下文入口用于告诉 AI 当前项目有哪些材料可以先查，以及每个入口应该如何读取或调用。

这个能力只做入口索引和调用提示，不做门禁、准入准出或证据裁决。

## 状态文件

项目上下文入口记录在用户工作目录：

```text
.kfc/project-context.json
```

## 入口类型

常用类型：

- `file`：本地文件。
- `directory`：本地目录。
- `url`：普通网页或文档链接。
- `feishu-doc`：Feishu 文档，默认使用 Feishu MCP 读取。
- `repository`：代码仓库或模块入口。
- `scripts`：其他稳定参考入口。

## 路由推进器命令

查看入口：

```bash
node kfc-flow-router/scripts/kfc.js context --root <dir>
```

登记入口：

```bash
node kfc-flow-router/scripts/kfc.js context-add --root <dir> --id <id> --title "<title>" --ref "<path-or-url>" --type <type>
```

按阶段或 skill 过滤：

```bash
node kfc-flow-router/scripts/kfc.js context --root <dir> --stage requirement
node kfc-flow-router/scripts/kfc.js context --root <dir> --skill kfc-worker-lightweight-prd
```

移除入口：

```bash
node kfc-flow-router/scripts/kfc.js context-remove --root <dir> --id <id>
```

## AI 使用规则

当 `route` 或 `continue` 返回 `project_context_entries` 时，AI 应判断这些入口是否与当前材料、阶段或选中 skill 相关。

相关时，AI 必须先按 `call_hint` 读取或调用入口，再输出阶段判断、可用 skills、建议下一步或产物结果。

不相关时，AI 可以说明本次未使用这些入口。

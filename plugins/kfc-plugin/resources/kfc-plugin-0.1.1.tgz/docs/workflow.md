# KFC Workflow

## 用户动作

```mermaid
flowchart TD
  A["用户输入 /kfc ..."] --> B["识别动作"]
  B -->|链接 / 文件 / 文本材料| C["读取材料并判断阶段"]
  B -->|当前| D["读取当前 workflow 状态"]
  B -->|有哪些 skills| E["展示当前阶段 skills"]
  B -->|上下文 / 记录上下文| Q["维护项目上下文入口"]
  B -->|继续| F["使用默认建议 skill"]
  B -->|用 skill 继续| G["使用用户指定 skill"]
  B -->|接入 / 移除 skill| H["维护动态 skill"]
  B -->|设置默认 skill| U["维护用户默认 skill"]
  B -->|更新| I["输出更新命令"]

  C --> J["匹配或创建 workflow"]
  J --> S["检查材料 / 状态 / 已有产物焦点是否一致"]
  S --> K["必要时由 AI 复核后同步 .kfc 状态"]
  K --> L["输出阶段、skills 和默认建议 skill"]
  Q --> L

  L --> T["停止等待用户选择继续方式"]
  F --> M
  G --> M
  M["AI 检查已有产物后使用已选择的 skill 工作"]
  Q --> R["返回入口和调用提示"]
  U --> R
  R --> P
  M --> N["skill 输出产物路径和作用"]
  N --> O["路由推进器 complete 按 workflow / 阶段 / 阶段子步骤记录产物"]
  O --> P["输出当前结果和下一步"]
```

## 多 Workflow 选择

```mermaid
flowchart TD
  A["收到材料"] --> B["路由推进器返回材料类型和候选状态"]
  B --> C["AI 读取材料内容"]
  C --> D["AI 对照所有 workflow"]
  D --> E{"是否唯一匹配?"}
  E -->|是| F["继续匹配 workflow"]
  E -->|否| G{"是否没有匹配?"}
  G -->|是| H["创建新 workflow 或说明将初始化"]
  G -->|否| I["列出候选 workflow 让用户选择"]
```

没有 workflow 状态时，`route --material` 会自动补建 workflow。补建不默认从需求阶段开始，而是复用正常阶段定位逻辑：先按材料推断候选阶段，再按阶段顺序向前检查材料证据；候选阶段没有足够材料支撑时，回退到前一阶段，直到找到能被当前材料支撑的阶段。返回结果和状态记录都会包含 `stage_evidence`，用于解释初始阶段为什么落在该位置。

## 阶段流转

```mermaid
stateDiagram-v2
  [*] --> requirement
  requirement --> solution_outline
  solution_outline --> detailed_design
  detailed_design --> task_breakdown
  task_breakdown --> development_execution
  development_execution --> test_and_selftest
  test_and_selftest --> acceptance_guide
  acceptance_guide --> acceptance_feedback
  acceptance_feedback --> [*]
```

## `/kfc 继续` 闭环

普通路由、当前状态或 skills 展示只给出可用 skills 和默认建议 skill，不得自动执行。只有用户明确输入 `/kfc 继续` 或 `/kfc 用 <skill-name> 继续吧` 后，AI 才能进入执行闭环。

默认建议 skill 的来源优先级为：用户显式指定 skill > 用户默认 skill > KFC 系统默认 skill。用户默认 skill 保存在用户全局注册器中，更新 KFC 不会覆盖。

```mermaid
sequenceDiagram
  participant U as User
  participant A as AI
  participant R as 路由推进器
  participant W as Skill

  U->>A: /kfc 继续
  A->>R: continue
  R-->>A: selected_skill + 当前阶段子步骤 + output_purpose + 建议产物目录
  R-->>A: active_step_session = in_progress
  A->>W: 使用默认建议 skill 工作
  W-->>A: 可能继续追问或多轮加工
  W-->>A: 产物路径 + 产物作用 + produced_by
  A->>R: complete --output-path --purpose
  R-->>A: 关闭 active_step_session 并更新 workflow 状态
  A-->>U: 最终回复：## 先看这里
```

如果用户输入 `/kfc 用 <skill-name> 继续吧`，AI 使用 `continue --skill <skill-name>`，后续产物记录闭环相同。

`/kfc 继续` 后不是一次性调用 skill。路由推进器会把当前阶段子步骤写成 `active_step_session.status=in_progress`。在该 session 关闭前，AI 必须继续同一个 `selected_skill`，不得重新路由、跳到下一阶段子步骤，或因为 skill 已经调用过一次就直接完成。多轮 skill 是否继续追问、继续加工或产出文件，由 skill 自己判断；KFC 只负责记录当前 session、产物路径和步骤推进。

## 开发类固定子步骤

开发类任务会固定覆盖以下子步骤：

```mermaid
flowchart TD
  A["development-execution.tdd_execution<br/>kfc-worker-development-execution"] --> B["development-execution.development_record<br/>kfc-worker-development-record"]
  B --> C["test-and-selftest.automated_verification<br/>kfc-worker-automated-verification-runner"]
  C --> D["test-and-selftest.runtime_selftest<br/>kfc-worker-runtime-selftest-recorder"]
  D --> E["test-and-selftest.code_review<br/>kfc-worker-code-review"]
  E --> F["test-and-selftest.security_review<br/>kfc-worker-security-review"]
  F --> G["test-and-selftest.review_readiness_packaging<br/>kfc-worker-review-readiness-packager"]
```

`route` 未收到 AI 复核后的 `--stage` 时，只返回 `inferred_stage` 和 `flow_node_check`，不会把不同焦点直接写入当前 workflow 状态。AI 读完材料和已有产物后，再按需要用 `route --stage <stage-id>` 同步状态。

## 用户可见输出

KFC 本轮最终用户回复以 `## 先看这里` 开头，并说明。中间进度、工具执行状态、材料读取状态和路由转交说明不使用该标题。

- 当前结论
- 当前 workflow
- 当前阶段
- 当前阶段子步骤
- 下一阶段，即下一阶段子步骤所属阶段
- 下一阶段子步骤
- 当前阶段可用 skills
- 本次参考的项目上下文入口
- 本次节点检查结论
- 建议产物目录
- 建议 skill
- 本次产物路径和作用
- 下一步可输入的命令
